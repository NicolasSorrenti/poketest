# LACA — Character Visual Bible

**Project:** Neo Campus Pokémon TCG RPG / visual novel  
**Character ID:** `laca`  
**Scope:** Physical appearance and visual-production continuity only. Character voice and personality are described separately in `character_bible.md`; lifeguard career is approved; exact venue, backstory, deck and story arcs are not yet approved.  
**Reference basis:** Thirteen AI-generated reference images supplied by the user on 2026-10-23, plus approved generated character art.  
**Status:** Appearance direction v1.5. Creator-confirmed canon: **20 years old, 167 cm, black fitted top with light-wash jeans**. These values are design decisions, not measurements from the reference pictures.


## v1.5 — creator-approved appearance and wardrobe refinements (2026-10-23)

- The **fourth image of the supplemental reference batch** (`references/12_PRIMARY_FACE_GOLDEN_HOUR.png`, close beach portrait in a black lace-up top) is the **primary facial identity anchor**. Match its eyebrow shape, almond eyes, nose, gentle jawline, and lips more faithfully than generic anime beauty conventions.
- **Longer, dark, separated, curved upper eyelashes are canonical**, as confirmed after several expression revisions.
- Creator requested **a slimmer physique** than the first expression artwork; preserve a natural, proportionate slim-curvy adult silhouette without overemphasizing chest or broadening the shoulders.
- `assets/laca_approved_expression_long_lashes.png` is the **approved expressive face treatment**: use it for eyelashes, facial fidelity, softness of features, and visual finish. That image's blush/open-mouth expression is **not the default neutral expression**.
- The extracted `assets/laca_fullbody_neutral_DRAFT.png` is **for review only**. It originates from a montage and is **not a transparent, production-ready VN sprite**, and has **not been explicitly approved**.
- Personality direction is **bold, cheeky and mischievous** as explicitly selected by the creator. Her lifeguard (guardavidas) profession is also creator-approved. Full backstory, exact workplace, schedule, event storyline and deck remain undecided. Do not infer additional traits from expressions, outfits or reference photography; consult `character_bible.md` for the proposed voice and character depth.
- **Wardrobe canon (v1.5):** On-duty Laca wears lifeguard swimwear frequently, especially in **morning waterfront encounters**. Her black fitted top + light-wash jeans remain the approved **civilian/off-duty** appearance. Red rescue swimwear is the proposed visual design, pending swimsuit artwork approval.
- **Production rule:** ONE subject on ONE full canvas per generated asset. No concept-sheet grids, collage, turnarounds, or text embedded in production art.

## 1. Canon lock / one-line description

Laca is an **adult Argentine Latina** with **very long dark espresso-brown hair**, **warm light-to-medium olive skin**, **deep brown almond-shaped eyes**, **full natural brows**, a **soft oval face**, and a **slim-curvy, defined-waist silhouette**. Draw her as a recognizably consistent adult woman in the game's polished anime/JRPG visual-novel style—not a generic anime model.

## 2. Physical continuity — DO NOT DRIFT

| Feature | Canonical direction | Continuity notes |
|---|---|---|
| Origin / visual identity | Argentine Latina, explicitly set by creator | Never replace her distinct facial anatomy with an ethnic caricature. |
| Age | **20 years old — approved canon** | Creator-confirmed in-game age; not inferred from reference images. |
| Height | **167 cm — approved canon** | Creator-confirmed height; preserve relative scale in any group art. |
| Body type | Slim-curvy and more slender than early generations; natural narrow waist, comparatively slim arms and shoulders, rounded hips and thighs with balanced bust; believable anatomy | Neither extremely thin nor exaggerated pin-up. Do not enlarge bust/hips between expressions. Preserve bodily proportions across outfits and camera angles. |
| Skin | Light-to-medium olive with warm golden/neutral undertones | Lighting and sun exposure vary among images; keep the same base complexion from scene to scene. |
| Hair color | Almost-black espresso/dark chocolate brown; naturally dark, not blue-black | Hair may catch warm brown highlights in sunlight. No colored streaks or sudden color shifts. |
| Hair length | Very long, extending well below the chest toward the waist, about mid-back or longer from behind | Maintain length in full-body, portrait, and CG views. |
| Hair shape | Predominantly straight with soft natural movement and occasional loose waves at the ends; thick, dense fall | Generally worn loose, subtly off-center/side part; can be tucked behind an ear. No straight-cut fringe or short bob. |
| Eyes | Deep warm brown, almond-shaped, slightly lifted outer corners | Use **visibly long, full, dark upper eyelashes** without oversizing the iris; creator-approved detail. |
| Brows | Distinctive thick, dark, natural brows with gentle arch | Essential to resemblance; do not make pencil-thin brows. |
| Face | Soft oval with gently tapered lower face, softly rounded cheeks, delicate but defined jaw/chin | Preserve facial width and cheek-to-jaw geometry even when smiling. |
| Nose | Relatively straight, refined, medium-small bridge and tip | Avoid tiny button-nose simplification. |
| Lips | Medium-full, naturally shaped lips with defined cupid's bow and fuller lower lip | Neutral, pink-rose/nude shades; avoid permanent exaggerated pout. |
| Makeup | Typically subtle, clean makeup; optional fine eyeliner, **long dramatic but separated upper eyelashes**, and natural lipstick | Makeup may change with outfit, not facial structure. |
| Piercings | Small understated earrings; a navel piercing appears in several early reference images | Navel jewelry is **optional**, not a permanent must-show identity feature, as later references do not consistently depict it. |
| Tattoos | No recurring tattoo clearly established across the eight references | Do not invent visible tattoos in primary assets. |

### Facial identity anchors (highest priority)

1. Thick dark eyebrows framing a soft, slightly elongated oval face.
2. Dark almond eyes, not enormous circular anime eyes.
3. Long, nearly black hair framing both sides of the face.
4. Naturally defined lips and a softly tapered chin.
5. Warm olive complexion, rendered consistently despite lighting changes.

## 3. Reference-image priority

- **Reference 07 — blue door / blue top / ivory trousers:** strongest baseline for **full-body standing proportions** and a modern casual outfit.
- **Reference 08 — sunset beach:** strong natural-light reference for **face, smile, skin tone, body silhouette, and hair**; account for warm sunset light.
- **References 01, 02, 03, 05:** compare for **facial identity, eyebrows, eyes, lips, hair density, and hairline**; image angles differ.
- **Reference 06:** useful for a side/three-quarter view and hair flow, but has low-quality tinted lighting.
- **Reference 04:** has strong wide-angle/tilted perspective distortion; use for general body characteristics, **not** precise anatomy or proportions.

**Identity rule:** All eight images depict the same intended character. Reconcile lighting, lens distortion, and changes in styling into one stable canon; do not alternate between an 'early photo face' and a 'later photo face'.

## 4. Clothes and visual styling

### Approved default portrait outfit — CANON LOCK

**Off-duty/civilian default:** **fitted black top** with **light-wash blue jeans**. Keep the fit natural and flattering, with credible fabric folds and construction; small understated earrings and/or minimal jewelry are optional. Reference 01 is a useful black-top/denim wardrobe anchor; References 07 and 08 remain the stronger references for full-body proportions and lighting. Do not substitute the blue crop top or the white skirt for this approved default. Keep the outfit realistic and SFW.

### Clothing variants supported by references

- **Original black crop-top variant:** Black cropped sleeveless top and pale blue jeans, as seen in Reference 01; a variation on the canonical everyday look.
- **Going out:** Black fitted top with short ivory/white skirt, silver necklace and understated earrings.
- **Relaxed:** Light pastel fitted blouse with jeans.
- **Blue-door look:** Cobalt/azure cropped top with ivory wide-leg trousers, as in Reference 07; an alternate outfit, not the default.
- **Beach/leisure:** Black or colorful patterned bikini, usable when she is swimming or spending time off duty; distinct from her professional lifeguard uniform. Do not substitute leisure swimwear for her approved everyday civilian portrait.

**Creator-approved profession and on-duty wardrobe:** Laca is a lifeguard (*guardavidas*) and **spends much of her working time in a swimsuit**. This is a normal, frequent character look, **especially when the player encounters her at the supervised waterfront in the morning**. A practical, recognizable red/coral rescue swimsuit (one-piece or professional two-piece pending art approval), rescue tube/buoy, whistle and appropriate footwear are recommended. A cover-up, rashguard, shorts or rescue shirt may be added for conditions, weather and duty requirements. Her black fitted top and light-wash jeans remain **the creator-approved civilian/off-duty outfit**, not the wardrobe for every on-duty scene.

### Contextual wardrobe / encounter rules — approved direction

- **Morning + supervised waterfront / on duty:** Show Laca **normally in her lifeguard swimsuit**. This is her signature work look, not a rare event CG outfit. Accessories and rescue gear should make the profession unmistakable.
- **Morning + elsewhere:** Match the activity, not merely the time. She may be in civilian clothes if buying breakfast or traveling, and in a cover-up during training or breaks.
- **Afternoon + still on shift / supervised swimming area:** Keep the lifeguard swimsuit; **do not automatically change her into jeans at noon**.
- **Afternoon after shift / evening / indoor casual encounters:** Default to the approved black fitted top and light-wash jeans, unless an individual scene justifies other clothing.
- **Swimming or beach leisure:** Alternative tasteful swimwear is acceptable, but distinguish recreation from safety duty.
- **Art production:** Prepare **two distinct portrait bases** using identical facial identity and proportions: `neutral_civilian` (black top and jeans) and `neutral_lifeguard` (working swimsuit and rescue details). Expressions derive separately from the appropriate base. No outfit switches mid-conversation without a narrative reason.

Do not infer personality from outfits; the selected personality direction is documented separately in `character_bible.md`.

## 5. Palette anchors (approximate artistic targets)

| Part | Direction | Approximate hex, not exact sampled values |
|---|---|---|
| Hair | Espresso / near black | `#241A1B` |
| Eyes | Warm dark brown | `#3A261F` |
| Skin midtone | Golden-olive light/medium | `#C58D73` |
| Lip | Muted rose nude | `#AD6A71` |
| Canonical top | Soft near-black | `#1C1A1D` |
| Canonical jeans | Light denim blue | `#ADC5D8` |
| Work swimsuit (proposed design) | Rescue red / coral | `#D5333A` |
| Alternate blue top | Azure / cobalt | `#087FAF` |
| Alternate trousers | Warm ivory | `#F0EADF` |

Colors are palette guides only. Lighting should affect painted appearance without changing identity.

## 6. Portrait and animation rules

- **Art style:** Consistent with Neo Campus's established polished anime/JRPG visual-novel portraits: attractive adult anatomy, deliberate linework, credible fabrics, clean shading and expressive but recognizably consistent faces.
- **First milestone:** **two separate standalone neutral portraits**, one civilian and one on-duty lifeguard, each with one woman, complete hands/feet when full-body, relaxed posture and context-appropriate expression; **no collage, grid, alternate poses, split panel, labels, or reference-sheet layout**.
- **Two asset types are distinct:** A review/reference portrait may have its own clean background (`assets/neutral.webp`); the game overlay version must be an independently prepared **transparent** PNG (`neutral.png` at the integration path specified by the game's manifest). Do not accidentally bake the background into an overlay.
- **Expression variations:** Happy, surprised, embarrassed, sad, angry, etc. as **separate outputs** based on the approved neutral master. Only facial expression, modest head angle, and slight gesture may change; preserve body, outfit, face, hairline, hair length, eyes, and accessories.
- **Cut-ins, chibi, and CGs:** All derived from the approved master. Chibi still needs Laca's signature brows, hair color/length, and eye shape. Each CG is an independent single scene, not a storyboard grid. For story CG framing, maintain a dialogue-safe low-detail area at the bottom where appropriate.
- **No visual drift:** No random eye-color shifts; no hair shortening; no lightening to chestnut; no new bangs, tattoos, facial piercings, or dramatically changed proportions; no generic anime replacement face.
- **No anatomy errors:** two arms, two legs, correctly placed fingers and shoulders; no duplicate limbs or accessories.

## 7. Approved-production prompt (working master)

> One **20-year-old** Argentine Latina woman named Laca, **167 cm tall**, polished modern anime/JRPG visual novel illustration. She has very long almost-black espresso-brown straight hair with soft natural movement, a slight side part, warm light-to-medium olive skin, deep brown almond eyes, full gently arched dark eyebrows, a softly oval face and subtly tapered chin, a refined straight nose, naturally full lips, and a balanced, defined-waist curvy silhouette with rounded hips and proportionately fuller bust. Her expression is calm and neutral with relaxed posture. Wearing a fitted black top and light-wash blue jeans, with minimal understated jewelry. Full-body standing pose, front three-quarter view, hands relaxed and fully visible, feet in frame, accurate adult human anatomy, consistent facial identity, flattering balanced studio lighting, clean cohesive line art and elegant cel/painterly shading. **A single standalone illustration only. No grid, no collage, no text, no extra character.**

For the production **overlay** render, require transparent alpha background; for a review master render, use a simple non-distracting background. Never request both outputs in the same generated image.

### Negative guardrails

> No blue/light eyes, no light-brown/blonde hair, no straight heavy bangs, no short bob, no heavy artificial makeup, no invented tattoos, no changes to face geometry, no disproportionate bust or hips, no doll-like child proportions, no chibi in the primary portrait, no hypersexual posing, no multiple people, no duplicate limbs, no crop of feet or hands, no text, no watermark, no character sheet, no collage.

## 8. Asset plan — for later production, not generated yet

1. Creator-approved neutral full-body **single** portrait.
2. Game-ready transparent neutral sprite derived from approved portrait.
3. Separate happy/sad/angry/surprised/embarrassed expression variants.
4. One simplified chibi for discreet mode.
5. Optional duel cut-in and any story CGs after role/story decisions.

## 9. Explicitly open decisions

- **Canonical age:** **20 years — locked by creator.**
- **Canonical height:** **167 cm — locked by creator.**
- **Default civilian outfit:** **fitted black top + light-wash blue jeans — locked by creator.** **Morning waterfront on-duty portrait:** working lifeguard swimsuit frequently shown — creator-approved direction; exact red suit cut pending final art approval.
- **Navel piercing:** optional until explicitly chosen.
- **Personality direction:** creator-approved bold, cheeky and mischievous; see `character_bible.md` for a draft voice and nuanced interpretation. **Occupation:** lifeguard (guardavidas) approved. **Exact workplace, backstory, schedule, deck and romance progression:** still unapproved.

**Preservation rule:** Once a neutral portrait is approved, its facial identity and silhouette take precedence over later generative reinterpretations. Any future wardrobe or expression change should use that asset plus these references as identity anchors.
