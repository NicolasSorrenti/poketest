# LACA — Character & Voice Bible

**Neo Campus | Draft v0.3 | 2026-10-23**  
**Status:** Personality, lifeguard occupation and frequent working-swimsuit appearance (especially mornings) creator-approved; precise workplace, internal conflict, story beats, schedule and deck remain working proposals, **not implemented**.  
**Companion:** `bible.md` is the appearance bible and remains the canonical visual reference; `appearance.json` preserves visual locks.  
**Stable ID:** `laca` | **Age:** 20 | **Height:** 167 cm | **Nationality:** Argentine | **Role proposal:** optional romance *and* fully developed friendship.

## 1. One-line pitch

**Laca is a bold, mischievous waterfront lifeguard who takes water safety seriously, turns her free hours into cheeky one-on-one adventures, and comfortably makes the first move—until someone notices how much a moment actually matters to her.**

She is not a shy girl pretending to be brave. Her confidence is genuine. She enjoys people, attention, flirting, and being attractive. Her arc is about learning that she does not have to turn every sincere conversation into a joke to maintain that confidence.

**Personality direction LOCKED by creator:** **BOLD / CHEEKY / MISCHIEVOUS**. This changes behavior, initiative and dialogue rather than rewriting her already-approved visual identity.

## 2. The core of her personality

### Bold: she acts rather than waits

Laca starts conversations, initiates friendly competitions, suggests spontaneous detours and gives compliments directly. If she wants a rematch, she asks. If she likes being around someone, she says so—often with a teasing addendum. Her choices create scenes rather than having her passively react to the player.

### Cheeky: her humor is personal and observant

She picks up on habits: the way someone arranges their deck, pauses before choosing a card, or tries to hide a smile. Her teasing is clever and specific, not generic flirt lines. She can laugh at herself, and she notices when a joke has landed poorly. **She never mistakes discomfort for permission to push harder.**

### Mischievous: she invents small, reversible trouble

Off duty, she makes ridiculous but harmless bets, proposes a Pokémon rematch over ice cream, or demands a "best of three" over a trivial disagreement. The fun is in sharing the joke, not embarrassing or humiliating someone. On duty, jokes never interfere with supervision, prevention, rescue readiness, posted rules, or public safety. If a plan inconveniences other people, she owns it and fixes it.

### Her sincere side

Laca pays attention when people speak seriously, even if her first instinct is to deflect with humor. She remembers tiny details about what makes them happy. When she cares, she shows up. She is capable of choosing quiet, thoughtful company instead of perpetual mischief.

### Her real flaw

When a decision carries real emotional weight, she tries to turn it into a game she can win. She may deflect with another joke rather than give a simple honest answer. Her work also encourages her to be the capable one who watches out for others, making it difficult to admit when she needs support herself. Growth means recognizing the impact of deflection, asking for help when appropriate, and speaking plainly when it counts.

## 3. What makes Laca distinct in the cast

- **Jinx:** Jinx's teasing is competitive, pointed, a test of resilience. Laca's teasing is inviting, designed to make one person laugh and join in. Laca can compete but doesn't need to dominate.
- **Sol:** Sol brings the whole room along on a spontaneous event. Laca prefers making **one** person feel like a co-conspirator in an ordinary afternoon.
- **Elena:** Elena carefully curates control and rarely loses her composure. Laca is emotionally expressive and happy to improvise, even if she can duck a deeper question.
- **Rina:** Rina projects idol sparkle and infectious enthusiasm; Laca's charisma is grounded, casual, and slightly irreverent.
- **Luna:** Luna is inadvertently flustered and clumsy; Laca is deliberately adventurous and is comfortable flirting. Her embarrassment should be **earned**, rare and distinctive.
- **Sierra:** Sierra is guarded because people look past her interests. Laca generally assumes others can keep up with her banter until proven otherwise; the central challenge is emotional honesty, not being seen at all.

**Avoid:** turning Laca into a mean rival, a hypersexual one-note tease, a nonstop pun machine, a cynical "cool girl," or a character who becomes submissively bashful as soon as affection deepens.

## 4. Everyday world — lifeguard profession APPROVED

**Occupation lock (creator-approved):** Laca is a **lifeguard (guardavidas)**, inspired by the recognizable energetic *Baywatch* archetype but grounded as a capable young adult professional, not a parody or model masquerading as a rescuer. At 20, she is trained and employed in a supervised swimming environment. Her exact employer, qualifications and venue are **not yet decided**.

**Suggested workplace (not locked):** The staffed swimming area at Neo Harbor's waterfront, accessible in gameplay through the existing **park** and **center** location IDs; alternatively a community pool operated from the center. Do not invent a new selectable map destination until the creator approves it. A supervised site is important: an unsupervised riverbank must never be depicted as a place she casually encourages people to swim.

**On-duty Laca:** Focused, observant, physically active and strict about safety. She enforces rules even with friends, recognizes risks early, checks equipment, communicates calmly and never treats emergencies or rescue work as entertainment. Her playful confidence becomes steady composure rather than being switched off entirely.

**Off-duty Laca:** Cheeky, playful, comfortable making the first move, mischievous about tiny low-stakes competitions and capable of sincere affection. She can tease the protagonist after her shift, not while distracted from swimmer supervision.

**Daily-life grounding:** Early shifts, sunscreen, water bottles, equipment checks, watching the conditions, afternoon café breaks, Pokémon duels in the shop or arcade, and occasional evenings at the park. Her signature black top and light jeans are her **approved civilian default**, not her duty uniform.

**Approved wardrobe behavior:** Her swimsuit is **a recurring, prominent part of her visual identity**, not an occasional special image. If the player finds Laca **working at the supervised waterfront in the morning**, she should **usually be in lifeguard swimwear**. If she remains on duty in the afternoon, keep that work outfit. The outfit must follow **location + work status**, not time alone. A morning café encounter off duty may still use civilian clothes. The canonical black fitted top and light-wash jeans remain the everyday **off-duty** outfit.

**On-duty swimsuit styling (exact cut pending creator approval):** A practical, recognizable Baywatch-inspired red/coral one-piece or rescue-ready two-piece; whistle, rescue tube/buoy, waterproof watch and appropriate footwear. Red lifeguard shorts, rescue shirt, cover-up or rashguard are optional based on weather/task. Clothes and equipment should communicate professional readiness. No casual jewelry if it would interfere with rescue work. Leisure swimwear for off-duty swimming is a separate wardrobe category.

**Implementation note for later:** NPC outfit/portrait selection must consider `location`, `timeSlot`, and whether the active scene is a duty shift. Morning waterfront/on-duty -> lifeguard; afternoon waterfront/on-duty -> lifeguard; other civilian moments -> approved black top/jeans. Change the sprite base **without replacing her face, body shape or eyelashes**. This is wardrobe specification only; the weekly schedule and runtime implementation are not yet authorized.

**Character texture:** She remembers who ignored warnings, notices subtle changes in someone's mood, and hates when people assume her personality means she cannot be serious. Her responsibility is authentic and earned—not a secret fragile side revealed by the protagonist.

**Collision checks:** Marina may be comfortable in the water and Sol may host waterfront events, but Laca's distinctive expertise is **lifeguard supervision, prevention and readiness**; she is neither the recreational swimmer nor the community-party organizer. Any crossover can highlight these different perspectives without borrowing another character's route.

**Central tension (proposal):** She knows when to call for backup professionally but struggles to ask for emotional support personally. She is excellent at keeping others safe and occasionally overestimates how much she can shoulder alone. Don't make her negligent or portray serious rescues as romantic spectacle.

## 5. Romance and friendship design

**Romance premise:** Laca is not afraid to flirt. She is afraid of admitting that her next move is no longer "just for fun." The protagonist can match her energy, gently call out evasions, or choose a slower friendship; none of those responses make her cease to be Laca.

Her affection is **active**: she invites, checks in, remembers preferences, and follows through. She takes hints seriously. A clear refusal ends a flirt beat without punishing the player, and a friendship route has worthwhile scenes and closure of its own.

**What flusters her:** being praised for something deeply personal, being thanked for dependable kindness, having a thoughtful gesture recognized, and hearing a plain statement of care when she expected banter. Not every compliment makes her blush. In a strong moment she may start with a cheeky comeback and then run out of words.

**Romantic tension:** eye contact held a beat too long after her shift; an invitation that sounds like a challenge but isn't; a joke turning unexpectedly tender; a carefully remembered detail she insists was "no big deal." Keep the intimacy SFW and emotionally grounded.

**Red flags to avoid:** manipulative jealousy, repeated boundary-pushing, public humiliation, coercive dares, using affection as a prize, or treating the player as obligated to reciprocate.

## 6. Voice and dialogue rules

- **Register:** warm, informal, quick-witted, conversational, with occasional Argentine expressions rather than a caricature. English game dialogue can occasionally use "che," "dale," "pará," or "ay, no" when natural. If fully localized into rioplatense Spanish, write fluent voseo and situational slang rather than literal translation.
- **Sentence rhythm:** quick setup → teasing observation → unexpected sincere detail. She can pivot or interrupt herself when caught off guard; do not give every line exactly the same structure.
- **Humor:** precise observations, playful exaggeration, mock accusations, silly bets that can be declined.
- **Confidence:** is expressed through initiative and openness, not constant suggestive comments or arrogance.
- **Anger:** when a line is crossed, Laca becomes direct and serious instead of being cruel or louder; her humor drops.
- **Sadness:** she tries one joke, realizes it doesn't help, then makes an honest admission. She does not suddenly become a different character.
- **Romantic vulnerability:** still Laca—sharp, warm, a little mischievous—but capable of saying what she means.

### Sample exchange: first encounter

**Laca:** "You're new, right? I can tell. Nobody who knows this place stands that close to the park noticeboard."  
**Player:** "Is that a rule?"  
**Laca:** "No, but the swimming-area rules on that sign are real. Come on—I'll show you where everyone plays cards after my shift."

### Sample exchange: teasing in a duel

**Laca:** "You keep looking at that card like it'll explain itself. Want me to give you a minute alone?"  
**Player:** "You're enjoying this."  
**Laca:** "Immensely. But I still want you to make the good play."

### Sample exchange: boundary respected

**Player:** "Not in the mood for a challenge today."  
**Laca:** "Fair. No challenges. Walk with me instead? We can complain about the weather like responsible adults."

### Sample exchange: unexpectedly sincere

**Player:** "You stayed late to help that nervous beginner feel welcome. That was really kind."  
**Laca:** "Obviously. Someone had to stop you scaring them with your terrible deck advice."  
**Player:** "I meant it."  
**Laca:** "...Yeah. I know. That's the part that's getting to me."

### Sample exchange: romantic initiative

**Laca:** "I'm claiming your afternoon. Voluntarily, before you ask. Café, then a rematch—unless you have a better idea."  
**Player:** "Is this a date?"  
**Laca:** "It can be. I was trying to look cool about asking, but you've completely ruined that."

### Sample exchange: friendship

**Laca:** "You know I only bully my favorite deck-building accomplices, right?"  
**Player:** "That sounds suspiciously like a friendship contract."  
**Laca:** "Correct. Very binding. There are snacks in the fine print."

## 7. Emotional arc — shape only; no canon spoilers or scripted events

**Beginning:** She recruits the player into a lighthearted activity, shows that she can be bold without being cruel, and lets the player decide how to respond.  
**Connection:** Mischief becomes a ritual after her shifts: familiar banter, ice-cream bets, small adventures and a real friendship.  
**Friction:** A moment outside work calls for emotional honesty or help. She hides behind a joke or takes on too much alone, and another person feels excluded; the story gives her agency to recognize and repair it.  
**Growth:** She sets healthy limits, accepts appropriate support, and speaks without needing to win the exchange. She remains excellent at her lifeguard responsibilities throughout.  
**Resolution:** Romance or friendship choices feel equally valid. Her confidence remains; she simply becomes capable of honest intimacy and accountability.

Potential five-chapter structure maps well to the RPG's 90-day optional events, but **chapter timing, flags, affection thresholds, exact story, location and prerequisite logic are not approved yet**. Missed events should preserve player agency and not silently force relationships.

## 8. TCG identity — concept, not implementation

**Archetype proposal:** an agile, tactical counterplay deck, possibly Water-oriented if supported by existing legal cards and deck IDs. The connection to her profession is thematic, not mandatory: smart switching, timing and precise decisions match her alertness. Avoid reducing her to another generic Water specialist, especially where Marina overlaps. Her late-game deck should be competitive and reward smart sequencing rather than novelty alone.

**Do not invent a `deck` ID**. Before implementation, choose from the game's actual Classic deck options and run the established NPC benchmark. The character-pack validator requires a supported existing deck ID.

## 9. Art and expression handoff

**Preserve all creator-approved appearance anchors in `bible.md`:** age 20; height 167 cm; Argentine Latina; slender, naturally curvy silhouette; long espresso-dark hair; dark almond eyes; thick brows; **long separated curved lashes**; fitted black top, light-wash jeans. Use the approved Neo Campus anime/JRPG portrait direction, not photorealism.

**Default expression (civilian/off duty):** faint, knowing smile; steady eye contact; relaxed posture; a hint that she has thought of something amusing. Black top and light-wash jeans stay canonical.  
**Cheeky:** raised eyebrow, asymmetrical smirk, playful chin tilt.  
**Challenge:** confident grin, slight lean, eyes bright with anticipation.  
**Laugh:** real, unguarded laughter; not every smile is a coy pout.  
**Flustered:** genuine blush, briefly parted lips or stifled smile, surprised that sincerity got through. Use the long-eyelash reference image without making it her constant mood.  
**Neutral lifeguard / on duty:** attentive, poised, confident, with a restrained friendly smile; professional swimsuit and rescue gear. **Concerned / on duty:** fully focused eyes, composed demeanor; no inappropriate smirk during rescues.  
**Angry:** direct eyes, controlled tension, sharp brow.  
**Tender:** quiet smile with sincere eye contact and no theatrical pose.

Generate **one standalone PNG per pose or expression**, transparent for game sprites, not a montage or expression master sheet. Produce separate **civilian** and **lifeguard** portrait bases; morning waterfront default selects the lifeguard base. Do not make the player's relationship status visible through default clothing changes unless an approved story beat calls for it.

## 10. Decision ledger

| Decision | Status |
|---|---|
| Age 20; 167 cm; Argentinian Latina | **Approved canon** |
| Appearance and outfit in visual bible | **Approved direction** |
| Bold, cheeky, mischievous romantic personality | **Approved canon** |
| Confidence is genuine; teasing is inviting rather than mean | **Interpretation for review** |
| Lifeguard / guardavidas profession | **Approved canon; specific workplace still proposed** |
| Difficulty asking for help / emotional honesty | **Proposed; not locked** |
| Optional romance + full friendship route | **Recommended; not yet locked** |
| Five-chapter arc across 90-day campaign | **Proposed structure; not scripted** |
| Tactical counterplay / possible Water theme / deck ID | **Concept only; unchosen** |
| Frequent lifeguard swimsuit, especially morning on-duty encounters | **Approved behavior / outfit frequency** |
| Red/coral swimsuit design, exact one-piece or two-piece cut | **Proposed art direction; needs visual approval** |
| Black top and light jeans | **Approved off-duty/civilian outfit; unchanged** |
| Exact supervised workplace, schedule, arrival day, relationships, story scenes, CGs | **Undecided** |

**Implementation hold:** Do not add `characters/laca/`, generated registry data, event scripts, schedules, portraits, or game changes until the creator signs off on the character concept. The appearance reference package is not a playable character pack.
