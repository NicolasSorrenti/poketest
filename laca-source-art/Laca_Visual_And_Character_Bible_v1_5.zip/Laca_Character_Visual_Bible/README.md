# Laca — Character Reference Package v1.5 (pre-implementation)

**Creator-approved**: 20 years old, 167 cm, Argentine Latina; fitted black top with light-wash jeans; primary facial reference #12; visibly long curled upper eyelashes; slimmer slim-curvy silhouette; **bold, cheeky, mischievous romantic personality; profession: lifeguard (guardavidas); **frequent lifeguard swimsuit appearance during on-duty waterfront encounters, particularly in the morning**. Black top/jeans remain her off-duty look**.

- `bible.md`: visual bible (canonical appearance details unchanged).
- `character_bible.md`: **new** voice, behavior, conflicts and romance/friendship concept with an explicit decision ledger.
- `appearance.json`: machine-readable appearance-only information.
- `generation_prompt.txt`: art-generation guidance.
- `references/`: all 13 original AI references; reference #12 is the creator-selected facial anchor.
- `assets/laca_approved_expression_long_lashes.png`: approved face/expression reference.
- `assets/laca_fullbody_neutral_DRAFT.png`: unapproved concept crop, NOT a game sprite.

**Still proposals**: specific supervised waterfront/pool workplace, exact design/cut of proposed red lifeguard swimsuit, central personal conflict, deck archetype, friendship/romance route shape. Story, deck ID, schedule, CGs and character-pack files are not implemented. No files in the GitHub repository have been changed.

**Creator-approved wardrobe behavior (v1.5):** Morning supervised waterfront/on duty usually means swimsuit; afternoons on duty may also show it. Time alone does not override location and work status. New lifeguard swimsuit art and outfit-routing code remain unimplemented.
